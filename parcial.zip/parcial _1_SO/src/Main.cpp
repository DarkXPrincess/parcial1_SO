#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <string>
#include <filesystem>

#include "RR.h"
#include "FCFS.h"
#include "MLQ.h"

using namespace std;
namespace fs = std::filesystem;

// ------------------ Parsers / IO ------------------
static bool leer_procesos(const fs::path& inpath, vector<Process>& processes) {
    ifstream file(inpath);
    if (!file.is_open()) return false;

    string line;
    while (getline(file, line)) {
        if (line.empty() || line[0] == '#') continue;
        stringstream ss(line);
        string id; int bt, at, q, pr; char sep;
        getline(ss, id, ';');              // id
        ss >> bt >> sep >> at >> sep >> q >> sep >> pr;
        processes.push_back({id, bt, at, q, pr, bt}); // remaining = bt
    }
    return true;
}

static void simular_y_guardar(std::vector<Process> processes,
                              const fs::path& outpath) {
    // Instancias frescas por cada archivo
    RR   rr3(3);
    RR   rr5(5);
    FCFS fcfs;
    MLQ  mlq({&rr3, &rr5, &fcfs});

    auto result = mlq.execute(processes);

    double avgWT = 0, avgCT = 0, avgRT = 0, avgTAT = 0;
    for (const auto& p : result) {
        avgWT += p.wt;
        avgCT += p.ct;
        avgRT += (p.rt == -1 ? 0 : p.rt);
        avgTAT += p.tat;
    }
    const int n = (int)result.size();
    if (n > 0) { avgWT/=n; avgCT/=n; avgRT/=n; avgTAT/=n; }

    ofstream out(outpath);
    out << "# etiqueta; BT; AT; Q; Pr; WT; CT; RT; TAT\n";
    for (const auto& p : result) {
        out << p.id << ";" << p.bt << ";" << p.at << ";" << p.q << ";" << p.pr << ";"
            << p.wt << ";" << p.ct << ";" << p.rt << ";" << p.tat << "\n";
    }
    out << fixed << setprecision(2)
        << "\nWT=" << avgWT << "; CT=" << avgCT
        << "; RT=" << avgRT << "; TAT=" << avgTAT << ";\n";
}

// Reúne entradas según tu estructura:
// - Si NO hay argumentos: toma todos los .txt de src/
// - Si hay argumentos: acepta archivos .txt y carpetas (añade sus .txt)
static vector<fs::path> recolectar_entradas(int argc, char** argv) {
    vector<fs::path> entradas;

    if (argc <= 1) {
        fs::path carpeta_src = "src";
        if (fs::exists(carpeta_src) && fs::is_directory(carpeta_src)) {
            for (auto& e : fs::directory_iterator(carpeta_src)) {
                if (e.is_regular_file() && e.path().extension() == ".txt")
                    entradas.push_back(e.path());
            }
        }
    } else {
        for (int i = 1; i < argc; ++i) {
            fs::path p(argv[i]);
            if (!fs::exists(p)) {
                cerr << "Aviso: no existe: " << p << "\n";
                continue;
            }
            if (fs::is_directory(p)) {
                for (auto& e : fs::directory_iterator(p)) {
                    if (e.is_regular_file() && e.path().extension() == ".txt")
                        entradas.push_back(e.path());
                }
            } else if (p.extension() == ".txt") {
                entradas.push_back(p);
            } else {
                cerr << "Aviso: se ignora (no .txt): " << p << "\n";
            }
        }
    }
    return entradas;
}

// ------------------ MAIN ------------------
int main(int argc, char** argv) {
    // 1) Entradas según estructura pedida
    vector<fs::path> entradas = recolectar_entradas(argc, argv);
    if (entradas.empty()) {
        cerr << "No se encontraron entradas .txt.\n"
             << "Opciones:\n"
             << "  - Coloca tus .txt en src/ y ejecuta sin argumentos.\n"
             << "  - O bien: " << argv[0] << " src mlq001.txt otra_carpeta\n";
        return 1;
    }

    // 2) Carpetas de salida en raíz
    fs::path outdir = "out";
    fs::create_directories(outdir);

    // 3) Procesar cada entrada
    int ok = 0, fail = 0;
    for (const auto& inpath : entradas) {
        vector<Process> procs;
        if (!leer_procesos(inpath, procs)) {
            cerr << "Error: no se pudo abrir '" << inpath.string() << "'.\n";
            ++fail;
            continue;
        }
        fs::path outpath = outdir / (inpath.stem().string() + "_salida.txt");
        simular_y_guardar(procs, outpath);
        cout << "OK: " << inpath.string() << " -> " << outpath.string() << "\n";
        ++ok;
    }

    cout << "Listo. " << ok << " archivo(s) procesado(s), " << fail << " con error.\n";
    return (fail == 0) ? 0 : 2;
}
